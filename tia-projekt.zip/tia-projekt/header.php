<script>
	function sha512(str) {
		return crypto.subtle.digest("SHA-512", new TextEncoder("utf-8").encode(str)).then(buf => {
			return Array.prototype.map.call(new Uint8Array(buf), x=>(('00'+x.toString(16)).slice(-2))).join('');
		});
	}

	$(document).ready(function(){
		$("#logout").click(function(){
			$("header").load("header.php",{
				logout : 1	
			});
		});		
	});
	
	$(document).ready(function() {
		$("#logininit").click(function(){
			$("header").load("header.php",{
				logininit: 1
			});
		});
	});
	
	$(document).ready(function() {
		$("#submitlogin").click(function(){
			
			var password = sha512($("#password").val()).then(function(x){
				$("header").load("header.php",{
					loginsubmit: 1,
					username: $("#username").val(),
					password: x
				});
			});
			
		});
	});
	
	$(document).ready(function() {
		$("#back").click(function(){
			$("header").load("header.php");
		});
		
	});
	
	$(document).ready(function() {
		$("#register").click(function(){
			$("#registration").attr("hidden", false);
			$("#registration").load("registration.php");
			$("#headerSpan").html("<b>Anonymous</b>");
		});
		
	});
</script>
<?php
	if (session_status() !== PHP_SESSION_ACTIVE){
		session_start();
	}

	if (isset($_POST['logout'])) {
		if (session_status() !== PHP_SESSION_ACTIVE){
			session_start();
		}
		session_unset();
		?>
		<script>
			reloadContent();
		</script>
		<?php
	}
	
	if (isset($_SESSION['uid'])){
		echo "Logged in as <b>".$_SESSION['uname']."</b>  <a href='profile.php?uid=".$_SESSION['uid']."'>Profile</a>";
		echo "<button id = 'logout'>Log out</button>";
		?>
		<script>
			reloadContent();
		</script>
		<?php
	}
	else{
		
		if (isset($_POST['loginsubmit'])){
			include "dbh.php";
			
			$sql = "SELECT * FROM user WHERE name = '".$_POST['username']."' AND password = '".$_POST['password']."'";
			$result = $conn->query($sql);

			if ($result->num_rows > 0) {
				if (session_status() !== PHP_SESSION_ACTIVE){
					session_start();
				}
				$row = $result->fetch_assoc();
				$_SESSION['uid'] = $row['id'];
				$_SESSION['uname'] = $row['name'];
				echo "Logged in as <b>".$_SESSION['uname']."</b>  <a href='profile.php?uid=".$_SESSION['uid']."'>Profile</a>";
				echo "<button id = 'logout'>Log out</button>";
				?>
				<script>
					reloadContent();
				</script>
				<?php
			} 	
			else{
				$_POST['logininit'] = 1;
			}
		}
		
		if (isset($_POST['logininit'])){
			echo "<b>Anonymous</b>";
			?>
				<label for = "username">Username:</label>
				<input type = "text" id = "username" name = "username">
				<label for = "password">Password:</label>
				<input type = "password" id = "password" name = "password">
				<button id = 'submitlogin'>Log in</button>
				<button id = 'back'><-</button>
			<?php
		}
		elseif (!isset($_POST['loginsubmit'])){
			echo "<span id = 'headerSpan'><b>Anonymous</b><button id = 'logininit'>Log in</button><button id = 'register'>Create new account</button></span>";
		}
	}
?>
<div id = 'registration' hidden></div>