<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
<script>
	var usernameCorrect = false;
	var passwordCorrect = false;
	var passwordMatch = false;
	
	$(document).ready(function() {
		$("#backRegister").click(function(){
			$("header").load("header.php");
		});
	});
	
	$(document).ready(function() {
		$("#register").click(function(){
			$("#registration").load("registration.php",{
				newUsername: $("#newUsername").val(),
				password1: $("#password1").val(),
				password2: $("#password2").val()
			});
		});
	});
	
	$(document).ready(function() {
		$("#newUsername").keyup(function(){
			var newName = $("#newUsername").val();
			var password1 = $("#password1").val();			
			var password2 = $("#password2").val();
			$.post("checkAvailability.php",{
				newName: newName
			}, function(data, status){
				$("#ava").html(data);
				if (data === "<b>Name available</b>"){
					usernameCorrect = true;
					$("#newUsername").css({"border":"3px solid #7EC8FF"});
				}
				else{
					usernameCorrect = false;
					$("#newUsername").css({"border":"3px solid red"});
				}
				
				if (usernameCorrect && passwordCorrect && passwordMatch){
					$("#register").attr("disabled", false);
				}
				else{
					$("#register").attr("disabled", true);
				}
			});
		});
	});
	
	$(document).ready(function(){
		$("#password1").keyup(function(){
			var password1 = $("#password1").val();
			var password2 = $("#password2").val();
			$("#long").html(password1.length > 4 ? "<b>Good password</b>" : "<b>Weak password</b>");
			if (password1.length > 4) {
				passwordCorrect = true;
				$("#password1").css({"border":"3px solid #7EC8FF"});
			}
			else{
				passwordCorrect = false;
				$("#password1").css({"border":"3px solid red"});
			}
			
			if (password1 === password2){
				passwordMatch = true;
				$("#match").html("<b>Passwords match</b>");
				$("#password2").css({"border":"3px solid #7EC8FF"});
			}
			else{
				passwordMatch = false;
				$("#password2").css({"border":"3px solid red"});
				$("#match").html("<b>Passwords are different</b>");
			}
			
			if (usernameCorrect && passwordCorrect && passwordMatch){
				$("#register").attr("disabled", false);
			}
			else{
				$("#register").attr("disabled", true);
			}
			
		});
	});
	
	$(document).ready(function(){
		$("#password2").keyup(function(){
			var password1 = $("#password1").val();
			var password2 = $("#password2").val();
			$("#match").html(password1 === password2 ? "<b>Passwords match</b>" : "<b>Passwords are different</b>");
			if (password1 === password2){
				passwordMatch = true;
				$("#password2").css({"border":"3px solid #7EC8FF"});
			}
			else{
				passwordMatch = false;
				$("#password2").css({"border":"3px solid red"});
			}
			
			if (usernameCorrect && passwordCorrect && passwordMatch){
				$("#register").attr("disabled", false);
			}
			else{
				$("#register").attr("disabled", true);
			}
		});
	});
	
</script>

<?php
	$render = true;
	if (isset($_POST['newUsername'])){
		include "dbh.php";
		
		$date = date('Y-m-d H:i:s');
		
		$sql = "INSERT INTO user(name,password,registration) VALUES ('".$_POST['newUsername']."','".$_POST['password1']."','".$date."')";
		$result = $conn->query($sql);
		
		$sql = "SELECT * FROM user WHERE name ='".$_POST['newUsername']."'";
		$result = $conn->query($sql);
		
		if ($result->num_rows > 0) {
			session_start();
			$row = $result->fetch_assoc(); 
			$_SESSION['uid'] = $row['id'];
			$_SESSION['uname'] = $row['name'];
			?>
			<script>
				$(document).ready(function(){
					$("header").load("header.php");
				});
			</script>
			<?php
		}
	}
	else{
?>
		<label for = "newUsername">Username:</label>
		<input type = "text" id = "newUsername" name = "newUsername"><span id ='ava'></span><br>
		<label for = "password1">Password:</label>
		<input type = "password" id = "password1" name = "password1"><span id = 'long'></span><br>
		<label for = "password2">Password:</label>
		<input type = "password" id = "password2" name = "password2"><span id = 'match'></span><br>
		<button id = 'register' disabled>Create</button>
		<button id = 'backRegister'><-</button>
		<span id = "tttt"></span>
<?php
	}
?>
<script>
	$("#newUsername").css({"border":"3px solid red"});
	$("#password1").css({"border":"3px solid red"});
	$("#password2").css({"border":"3px solid red"});	
</script>