<?php
	session_start();
	include "dbh.php";
	
	$sql = "INSERT INTO comments (tmid, comment, author_id) VALUES ('".$_POST['tmid']."','".$_POST['comment']."','".$_SESSION['uid']."')";
	$result = $conn->query($sql);

?>