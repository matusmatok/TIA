<?php
	include "dbh.php";
	
	$sql = "UPDATE turing_machines SET public ='".$_POST['p_public']."' where id ='".$_POST['tmid']."'";
	$result = $conn->query($sql);
?>