<?php
	session_start();
	include 'dbh.php';
?>

<!DOCTYPE html>
<html>
<head>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
	<script>
		
		var page = 0;
		
		function findGetParameter(parameterName) {
			var result = null,
				tmp = [];
			var items = location.search.substr(1).split("&");
			for (var index = 0; index < items.length; index++) {
				tmp = items[index].split("=");
				if (tmp[0] === parameterName) result = decodeURIComponent(tmp[1]);
			}
			return result;
		}
		
		function reloadContent(){
			$(document).ready(function(){
				if (true){
					let tmid = $("#tmid").html();
					let owner_id = $("#owner_id").html();
					let p_public = $("#p_public").html();
					
					let description = $("#description").val() === "" ? $("#description").html() : $("#description").val();
					let title = $("#title").val() === "" ? $("#title").html() : $("#title").val();
					let delta_function = $("#delta_function").val() === "" ? $("#delta_function").html() : $("#delta_function").val();
					let input_chars = $("#input_chars").val() === "" ? $("#input_chars").html() : $("#input_chars").val();
					let work_chars = $("#work_chars").val() === "" ? $("#work_chars").html() : $("#work_chars").val();
					
					let initial_state = $("#initial_state").html() === "" ? $("#initial_state").val() : $("#initial_state").html();
					let accepting_states = $("#accepting_states").html() === "" ? $("#accepting_states").val() : $("#accepting_states").html();
					let states = $("#states").html() === "" ? $("#states").val() : $("#states").html();
			
					var str = "runSubpage.php?tmid="+findGetParameter("tmid");
					$.post(str,{
						
						boot: $("#tmid").html() === "-1" ? false : true,
						tmid: tmid,
						description: description,
						title: title,
						owner_id: owner_id,
						p_public: p_public,
						delta_function: delta_function,
						input_chars: input_chars,
						work_chars: work_chars,
						initial_state: initial_state,
						accepting_states: accepting_states,
						states: states						
					}, function(data,status){
						$("#content").html(data);
					});
				}
				else{
					
				}
			});
		}
		
		class State{
			constructor(xpos, ypos, stateName){
				this.x = xpos;
				this.y = ypos;
				this.name = stateName;
				this.nextState = {};
				this.headMovement = {};
				this.writeChar = {};
				this.accept = false;
				this.current = false;
			}
			getNextState() {
				return this.nextState;
			}
			getHeadMovement(){
				return this.headMovement;
			}
			getWriteChar(){
				return this.writeChar;
			}
			setAsAccepting(){
				this.accept = true;
			}
			getX(){
				return this.x;
			}
			getY(){
				return this.y;
			}
			
		}
		
		class Graph{ 
			
			constructor(){
				this.gstates = {};
				this.currentState = undefined;
			}
			
			getCurrentState(){
				return this.currentState;
			}
			
			getStates(){
				return this.gstates;
			}
			
			goToNextState(character){
				let nextStateObj = this.currentState.getNextState();
				this.currentState.current = false;
				this.currentState = this.currentState.getNextState()[character];
				this.currentState.current = true;
			}
			
			addStatesWithOld(oldGraph){
				var res = $("#states").val().split(",");
				let states = this.gstates;
				let formerStates = oldGraph.getStates();
				if ($("#states").val() != ""){
					res.forEach(function(currentValue) {
						
						currentValue = currentValue.trim();
						
						if (formerStates[currentValue] == undefined){
							states[currentValue] = new State(80,80,currentValue);
						}
						else{
							states[currentValue] = formerStates[currentValue];
							states[currentValue].nextState = {};
							states[currentValue].headMovement = {};
							states[currentValue].writeChar = {};
							states[currentValue].accept = false;
							states[currentValue].current = false;
						}
					});
					
					this.currentState = this.gstates[$("#initial_state").val().trim()];
					this.currentState.current = true;
					
					var asr = $("#accepting_states").val().split(",");
					
					asr.forEach(function(currentValue) {
						let acceptState = currentValue.trim();
						states[acceptState].setAsAccepting();
					});
				}
	
			}
			
			addStatesFromJSON(text){
				let jsonObj = JSON.parse(text);
				let states = this.gstates;
				var res = $("#states").html().split(",");
				if ($("#states").html() != ""){
					res.forEach(function(currentValue){
						currentValue = currentValue.trim();
						let subObj = jsonObj[currentValue];
						if (jsonObj[currentValue] == undefined){
							states[currentValue] = new State(80,80,currentValue);
						}
						else{
							states[currentValue] = new State(subObj.x, subObj.y, currentValue);
						}
					});
					
					this.currentState = this.gstates[$("#initial_state").html().trim()];
					this.currentState.current = true;
					
					var asr = $("#accepting_states").html().split(",");
					
					asr.forEach(function(currentValue) {
						let acceptState = currentValue.trim();
						states[acceptState].setAsAccepting();
					});
				}
				
			}
			
			addStates(){
				var res = $("#states").html().split(",");
				let states = this.gstates;
				if ($("#states").html() != ""){
					res.forEach(function(currentValue) {
						currentValue = currentValue.trim();
						states[currentValue] = new State(80,80,currentValue);
					});
					this.currentState = this.gstates[$("#initial_state").html().trim()];
					this.currentState.current = true;
					
					var asr = $("#accepting_states").html().split(",");
					
					asr.forEach(function(currentValue) {
						let acceptState = currentValue.trim();
						states[acceptState].setAsAccepting();
					});
				}
			} 
			
			addDeltaFunction(){
				var deltaRaw = $("#delta_function").val().split(";");
				if ($("#delta_function").val() == "") deltaRaw = $("#delta_function").html().split(";");
				
				var self = this;
				if (deltaRaw != ""){
					deltaRaw.forEach(function(currentValue){ 
						var eqSides = currentValue.split("=");
						eqSides[0] = eqSides[0].trim();
						eqSides[1] = eqSides[1].trim();
						
						eqSides[0] = eqSides[0].slice(1, eqSides[0].length - 1);
						eqSides[1] = eqSides[1].slice(1, eqSides[1].length - 1);
						
						var fnParameters = eqSides[0].split("{");
						fnParameters[0] = fnParameters[0].trim();
						fnParameters[0] = fnParameters[0].slice(0, fnParameters[0].length - 1);
						
						fnParameters[1] = fnParameters[1].trim();
						fnParameters[1] = fnParameters[1].slice(0, fnParameters[1].length -1);
						fnParameters[1] = fnParameters[1].trim();
						
						var onChars = fnParameters[1].split(",");
						onChars.forEach(element => element = element.trim());
						
						var fnResults = eqSides[1].split(",");
						fnResults.forEach(element => element = element.trim());
						
						onChars.forEach(element =>
							self.addNewEdge(fnParameters[0], element, fnResults[0].trim(), fnResults[2].trim(), fnResults[1].trim())
						);
						
					});	
				}
			}
			
			addNewEdge(fromState, formerChar, toState, movement, newChar){
				var theState = this.gstates[fromState];
				var toTheState = this.gstates[toState];
				theState.nextState[formerChar] = toTheState;
				theState.headMovement[formerChar] = movement;
				theState.writeChar[formerChar] = newChar;	
			}
			
			createJSON(){
				var string = '{\n';
				let keys = Object.keys(this.gstates);
				let states = this.gstates;
				keys.forEach(function(key){
					let state = states[key];
					let substring = '"' + key + '" : {\n';
					substring += '"x" : ' + state.getX() + ',\n';
					substring += '"y" : ' + state.getY() + '\n';
					string += substring + '},\n';
				});
				string = string.slice(0, string.length -2);
				string += '}'
				return string;
			}
		}
		
		class TMTape{
			constructor(){
				this.tapeWord = "B" + $("#inputword").val() + "B";
				this.position = 1;
			}
			
			step(write, move){
				let prefix = this.tapeWord.slice(0, this.position);
				let sufix = this.tapeWord.slice(this.position + 1, this.tapeWord.length);
				this.tapeWord = prefix + write + sufix;
				this.position += parseInt(move);
				if (this.position == -1) {
					this.position = 0;
					this.tapeWord = "B"+this.tapeWord;
				}
				if (this.position == this.tapeWord.length){
					this.tapeWord = this.tapeWord + "B";
				}
			}

			produceString(){
				let prefix = this.tapeWord.slice(0, this.position);
				let sufix = this.tapeWord.slice(this.position + 1, this.tapeWord.length);
				return prefix + "<b><u>" + this.tapeWord[this.position] + "</u></b>" + sufix;
			}
			
			getCurrentChar(){
				return this.tapeWord[this.position];
			}
			
		}
		
		function refreshComments(){
			$(document).ready(function(){
				let tmid = $("#tmid").html();
				$.post("comments.php",{
					tmid: tmid
				},function(data,status){
					$("#comments").html(data);
				});
			});
		}
		
		function setUpCanvas(){
			$("#selector").css({"float" : "right",
			"margin-right" : "15px"});
			$("#edgeViewer").css({"float" : "right",
			"width": "170px",
			"margin" : "12px"});
			$("#editTitle").css({"width" : "194px", 
			"margin" : "0",
			"float" : "right",
			"text-align" : "center"});
			$("#canvasDiv").css({"float" : "right",
			"width" : "calc(100% - 500px)" });
			$("canvas").css({"background-color": "white",
			"float" : "left",
			"border" : "3px solid #2DA6FF"
			});
			$("#edgeEditor").css({
				"float" : "right",
				"width" : "158px",
				"margin" : "12px",
				"height" : "200px",
				"resize" : "none"
			});
			var canvas = document.querySelector('canvas');
			canvas.width = window.innerWidth - 680;
			canvas.height = document.getElementById('content').getBoundingClientRect().height - 120;
		}
		
		function drawLoop(context, x,y){
			context.beginPath()
			context.lineWidth = 2;
			context.strokeStyle = 'rgba(0,0,0, 1)';
			context.arc(x - 30, y -30, 30, 0, (Math.PI/2), true);
			context.stroke();
			context.moveTo(x - 30,y);
			context.lineTo(x - 38,y-9);
			context.moveTo(x - 30, y);
			context.lineTo(x - 38, y + 7);
			context.stroke();
		}
		
		
		function drawBetween(context, fromx, fromy, tox, toy) {
			var headlen = 10; 
			var dx = tox - fromx;
			var dy = toy - fromy;
			var angle = Math.atan2(dy, dx);
			var angle2 = Math.atan2(dx, dy);
			fromx = fromx + 30*Math.cos(angle);
			fromy = fromy + 30*Math.sin(angle);
			tox = tox - 33*Math.cos(angle);
			toy = toy - 33*Math.sin(angle);
			context.lineWidth = 2;
			context.strokeStyle = 'rgba(0,0,0, 1)';
			context.beginPath();
			context.moveTo(fromx, fromy);
			context.lineTo(tox, toy);
			context.lineTo(tox - headlen * Math.cos(angle - Math.PI / 6), toy - headlen * Math.sin(angle - Math.PI / 6));
			context.moveTo(tox, toy);
			context.lineTo(tox - headlen * Math.cos(angle + Math.PI / 6), toy - headlen * Math.sin(angle + Math.PI / 6));
			context.stroke();
		}

		
		function drawGraph(){
			console.log("draw");
			let canvas = document.querySelector('canvas');
			let c = canvas.getContext('2d');
			c.clearRect(0,0,canvas.width, canvas.height);
			let states = theGraph.getStates();
			let keyz = Object.keys(states);
			c.strokeStyle = 'rgba(0,0,0, 1)';
			c.lineWidth = 5;
			c.font = "25px Arial";
			keyz.forEach(function(element){
				let state = states[element];
				if (state.current){
					c.strokeStyle = 'rgba(0,0,255,1)';
					c.lineWidth = 5;
				}
				else{
					c.strokeStyle = 'rgba(0,0,0, 1)';
					c.lineWidth = 3
				}
				c.beginPath();
				c.arc(state.x, state.y, 30, 0, Math.PI*2, false);
				c.stroke();
				c.fillText(state.name, state.x-15, state.y+10);
				let nextStates = state.getNextState();
				nskeyz = Object.keys(nextStates);
				nskeyz.forEach(function(ns){
					
					let nextState = nextStates[ns];
					if (nextState.name === state.name){
						drawLoop(c, state.x, state.y);
					}
					else{
						drawBetween(c, state.x, state.y, nextState.x, nextState.y);
					}
				});
			});
		}
		
		function resizeCanvas(){
			var canvas = document.querySelector('canvas');
			canvas.width = window.innerWidth - 680;
			canvas.height = document.getElementById('content').getBoundingClientRect().height - 120;
			drawGraph();
		}
		window.addEventListener('resize', resizeCanvas, false);
		
		function rebootGraph(){
			try{
				var newGraph = new Graph();
				newGraph.addStatesWithOld(theGraph);
				newGraph.addDeltaFunction();
				theGraph = newGraph;
				drawGraph();
			}
			catch(error){
				
			}
		}
		
	</script>
	<link rel="stylesheet" href="global.css">
	<link rel="stylesheet" href="header.css">
</head>
<body>
<header>
<?php 
	include 'header.php';
?>
</header>
<div id = "content">
	<?php
	
		if (isset($_GET['tmid'])){
			$sql = "SELECT * FROM turing_machines WHERE id = '".$_GET['tmid']."'";
			$result = $conn->query($sql);
			
			if ($result->num_rows > 0){
				$row = $result->fetch_assoc();
				
				$_POST['tmid'] = $row['id'];
				$_POST['title'] = $row['title'];
				$_POST['description'] = $row['description'];
				$_POST['owner_id'] = $row['owner_id'];
				$_POST['p_public'] = $row['public'];
				$_POST['delta_function'] = $row['delta_function'];
				$_POST['code'] = $row['code'];
				$_POST['input_chars'] = $row['input_chars'];
				$_POST['work_chars'] = $row['work_chars'];
				$_POST['initial_state'] = $row['initial_state'];
				$_POST['accepting_states'] = $row['accepting_states'];
				$_POST['states'] = $row['states'];
				$_POST['json'] = $row['code'];
			}
			
			
			include "runSubpage.php";
			
		}
		else{
			$_POST['tmid'] = "-1";
			$_POST['title'] = "Untitled turing machine";
			$_POST['description'] = "No description..";
			$_POST['owner_id'] = "-1";
			$_POST['p_public'] = "1";
			$_POST['delta_function'] = "";
			$_POST['code'] = "";
			$_POST['input_chars'] = "";
			$_POST['work_chars'] = "";
			$_POST['initial_state'] = "";
			$_POST['accepting_states'] = "";
			$_POST['states'] = "";
			$_POST['json'] = "{}";
			
			include "editSubpage.php";
		}
	?>
</div>
<div id = 'newComment'>
	<?php
		include "newComment.php";
	?>
</div>
<div id='comments'>
	<?php
		include "comments.php";
	?>
</div>
<div id='json_graph' hidden>
	<?php
		echo $_POST['json'];
	?>
</div>
<?php 
	if (isset($_GET['tmid'])){
?>
<script>
	var theGraph = new Graph();
	theGraph.addStatesFromJSON($("#json_graph").html());
	theGraph.addDeltaFunction();
</script>
<?php
	}
	else{
?>
<script>
	var theGraph = new Graph();
	theGraph.addStates();
	theGraph.addDeltaFunction();
</script>
<?php
	}
?>

</body>

</html>