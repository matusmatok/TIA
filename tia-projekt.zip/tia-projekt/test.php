def search(node: Node):
        if not node.succs:
            if node.point is not None and region.xmin <= node.point.x < region.xmax and \
                    region.ymin <= node.point.y < region.ymax:
                return [node.point]
            return []
        if ((node.region.xmin <= region.xmin <= node.region.xmax) or (node.region.xmin <= region.xmax <= node.region.xmax)) \
                and ((node.region.ymin <= region.ymin <= node.region.ymax) or (node.region.ymin <= region.ymax <= node.region.ymax)):
            points = []
            for i in range(4):
                points += search(node.succs[i])
            return points
        return []
    return search(tree.root)