<?php
	include "dbh.php";
	
	if (isset($_POST['newName'])){
		if (strlen($_POST['newName']) < 5){
			echo "<b>Name is too short</b>";
		}
		else{
			$sql = "SELECT * FROM user WHERE name ='".$_POST['newName']."'";
			$result = $conn->query($sql);
			
			if ($result->num_rows > 0) {
				$row = $result->fetch_assoc();
				echo "<b>Name not available</b>"; 
			}	
			else{
				echo "<b>Name available</b>";
			}
		}
	}
?>