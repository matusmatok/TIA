<?php 
	session_start();
	if (isset($_SESSION['uid'])){
		echo "uid is ".$_SESSION['uid'];
	}
	else{
		echo "no such session var";		
	}
?>