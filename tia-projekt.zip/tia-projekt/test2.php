<?php
	$date = date('Y-m-d H:i:s');
	echo $date;
?>