<?php
	if (session_status() !== PHP_SESSION_ACTIVE){
		session_start();
	}
	include "dbh.php";
	
	$uid = $_POST['uid'];
	
	$sql = "SELECT * FROM user WHERE id='$uid'";
	
?>
<script>
	function handleClick(cb) {
		console.log(cb.name + " " + (cb.checked == true ? 1 : 0));
		$.post("updatePublic.php",{
			tmid : cb.name,
			p_public : (cb.checked == true ? 1 : 0)
		}, function(data, status){
			console.log("succes");
		});
	}
</script>
<div id = "userInfo">
	
	<?php
	
	$result = $conn->query($sql);
	if($result->num_rows > 0){
		$row = $result->fetch_assoc();
		echo "<p><b>Username:</b>  ".$row['name']."</p>";
		echo "<p><b>Registration:</b>  ".$row['registration']."</p>";
	}
		
	if (isset($_SESSION['uid'])){
		if ($_SESSION['uid'] != $_POST['uid']){
			echo "<button id = 'subscribe'>Subscribe</button>";
		}
	}	
		
	?>
</div>
<hr>
<div id = "touringMachines">
	<?php
		if (isset($_SESSION['uid'])){
			if ($_POST['uid'] == $_SESSION['uid']){
				echo "<a id='new' href='editRun.php'>Create new Turing machine</a><br>";
			}
		}
		
		$sql = "SELECT id AS tm_id, title, description, public FROM turing_machines WHERE owner_id ='".$_POST['uid']."'";
		//$sql = "SELECT turing_machines.id AS tm_id, turing_machines.title AS title, turing_machines.description AS description, turing_machines.public AS public FROM user JOIN ownership_relation ON user.id = ownership_relation.user_id JOIN turing_machines ON ownership_relation.tm_id = turing_machines.id WHERE user.id = $uid";
		if(!isset($_SESSION['uid'])){
			$sql = $sql." AND turing_machines.public = '1'";
		}
		elseif($_SESSION['uid'] !== $_POST['uid']){
			$sql = $sql." AND turing_machines.public = '1'";
		}

		$result = $conn->query($sql);
		if($result->num_rows > 0){
			while($row = $result->fetch_assoc()){
				echo "<div class = 'tm_overview'>";
				
				echo "<div class='actions'>";
				if(isset($_SESSION['uid'])){
					if ($_POST['uid'] == $_SESSION['uid']){
						
						echo "<a href='editRun.php?tmid=".$row['tm_id']."'>View or edit</a>";
						echo "<div class='public'>Public: <input type='checkbox' onClick = 'handleClick(this)' name = '".$row['tm_id']."' class = 'checkPub' ".($row['public'] == 1 ? 'checked' : "")." ></div>";
					}
					else{
						echo "<a href='editRun.php?tmid=".$row['tm_id']."'>View</a>";
					}
					
				}
				else{
					echo "<a href='editRun.php?tmid=".$row['tm_id']."'>View</a>";
				}
				echo "</div>";
				echo "<h4>".$row['title']."</h4>";
				echo "<p>".$row['description']."</p>";
				
				echo "</div>";
			}
		}
	?>

</div>
<script>
	$("#new").css({
		"margin-bottom" : "20px"
	});
	
	
</script>
