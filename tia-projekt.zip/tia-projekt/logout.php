<?php
	session_unset();
?>