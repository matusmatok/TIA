
<?php
	if (session_status() !== PHP_SESSION_ACTIVE){
		session_start();
	}
	
	include "dbh.php";
?>
<script>
	function findGetParameter(parameterName) {
		var result = null,
			tmp = [];
		var items = location.search.substr(1).split("&");
		for (var index = 0; index < items.length; index++) {
			tmp = items[index].split("=");
			if (tmp[0] === parameterName) result = decodeURIComponent(tmp[1]);
		}
		return result;
	}
	
	$(document).ready(function() {
		$("#gotoEdit").click(function(){
			
			let tmid = $("#tmid").html();
			let owner_id = $("#owner_id").html();
			let p_public = $("#p_public").html();
			
			let description = $("#description").html();
			let title = $("#title").html();
			let delta_function = $("#delta_function").html();
			let input_chars = $("#input_chars").html();
			let work_chars = $("#work_chars").html();
			
			let initial_state = $("#initial_state").html();
			let accepting_states = $("#accepting_states").html();
			let states = $("#states").html();
			
			let url = "editSubpage.php?tmid=" + findGetParameter("tmid");
			
			page = 1;
			
			$.post(url, {
				tmid: tmid,
				description: description,
				title: title,
				owner_id: owner_id,
				p_public: p_public,
				delta_function: delta_function,
				input_chars: input_chars,
				work_chars: work_chars,
				initial_state: initial_state,
				accepting_states: accepting_states,
				states: states
			}, function(data,status){
				$("#content").html(data);
			});
			
			
		});
	});
	
	/*$(document).ready(function(){
		$("#run").click(function(){
			var deltaRaw = $("#delta_function").html().split(";");
			if (deltaRaw !== ""){
				deltaRaw.forEach(function(currentValue){ 
					var eqSides = currentValue.split("=");
					eqSides[0] = eqSides[0].trim();
					eqSides[1] = eqSides[1].trim();
					
					eqSides[0] = eqSides[0].slice(1, eqSides[0].length - 1);
					eqSides[1] = eqSides[1].slice(1, eqSides[1].length - 1);
					
					var fnParameters = eqSides[0].split("{");
					fnParameters[0] = fnParameters[0].trim();
					fnParameters[0] = fnParameters[0].slice(0, fnParameters[0].length - 1);
					
					fnParameters[1] = fnParameters[1].trim();
					fnParameters[1] = fnParameters[1].slice(0, fnParameters[1].length -1);
					fnParameters[1] = fnParameters[1].trim();
					
					var fnResults = eqSides[1].split(",");
					fnResults.forEach(element => element = element.trim());
					
					//$("#inputword").val("state: "+fnParameters[0]+" characters: "+fnParameters[1] + " " + fnResults[0] + " " + fnResults[1] + " " + fnResults[2]);
				});
			}
		});
	});*/
	
		
	$(document).ready(function(){
		$("#nextStep").click(function(){
			let charAt = theTape.getCurrentChar();
			let writeChar = theGraph.currentState.writeChar[charAt];
			let move = theGraph.currentState.headMovement[charAt];
			theTape.step(writeChar, move);
			$("#simTape").html(theTape.produceString());
			
		});
	});
	
	$(document).ready(function(){
		$("#run").click(function(){
				
				theTape = new TMTape();
				
				let tapeString = theTape.produceString();
				let currentStateName = theGraph.currentState.name;
				$.post("simulation.php",{
					tape: tapeString,
					state: currentStateName
				}, function(data,status){
					$("#simulation").html(data);
				});
		});
	});
	

</script>
<?php	
	if (isset($_POST['boot']) && $_POST['boot']){
		$_POST['boot'] = false;
		$sql = "SELECT * FROM turing_machines WHERE id = '".$_GET['tmid']."'";
		$result = $conn->query($sql);
		
		if ($result->num_rows > 0){
			$row = $result->fetch_assoc();
			$_POST['tmid'] = $row['id'];
			$_POST['title'] = $row['title'];
			$_POST['description'] = $row['description'];
			$_POST['owner_id'] = $row['owner_id'];
			$_POST['p_public'] = $row['public'];
			$_POST['initial_state'] = $row['initial_state'];
			$_POST['accepting_states'] = $row['accepting_states'];
			$_POST['states'] = $row['states'];
			$_POST['delta_function'] = $row['delta_function'];
			$_POST['code'] = $row['code'];
			$_POST['input_chars'] = $row['input_chars'];
			$_POST['work_chars'] = $row['work_chars'];	
		}
	}	

	$show = true;
	
	if (isset($_POST['p_public']) && $_POST['p_public'] == 0){
		if (isset($_SESSION['uid']) && $_POST['owner_id'] !== $_SESSION['uid']){
			$show = false;
		}
		if (!isset($_SESSION['uid'])){
			$show = false;
		}
	}
	
	echo "<h1 id = 'page'>Run and test the turing machine</h1>";
	
	if ($show) {
		if ($_POST['tmid'] == -1 or (isset($_SESSION['uid']) && $_SESSION['uid'] == $_POST['owner_id'])){
			echo "<button id = 'gotoEdit'>Edit the turing machine</button><br>";
		}
	}

	
	if ($show){
		
		echo "<div id ='canvasDiv'><canvas></canvas></div>";
		echo "<div id = 'hidden' hidden><p id = 'owner_id' hidden>".$_POST['owner_id']."</p>";
		echo "<p id = 'p_public' hidden>".$_POST['p_public']."</p>";
		echo "<p id = 'tmid' hidden>".$_POST['tmid']."</p></div>";
		echo "<h2 id = 'title'>". (isset($_POST['title']) ? $_POST['title'] : "Untitled turing machine")."</h2>";
		echo "<p id = 'description'>". (isset($_POST['title']) ? $_POST['description'] : "No description..")."</p>";
		echo "<h4>Input characters:</h4>";
		echo "<p id = 'input_chars'>".$_POST['input_chars']."</p>";
		echo "<h4>Working characters: </h4>";
		echo "<p id = 'work_chars'>".$_POST['work_chars']."</p>";
		echo "<h4>States:</h4>";
		echo "<p id = 'states'>".$_POST['states']."</p>";
		echo "<h4>Initial state:</h4>";
		echo "<p id = 'initial_state'>".$_POST['initial_state']."</p>";
		echo "<h4>Accepting states:</h4>";
		echo "<p id = 'accepting_states'>".$_POST['accepting_states']."</p>";
		echo "<h4>Delta function</h4>";
		echo "<pre id = 'delta_function'>".$_POST['delta_function']."</pre>";
		
	}
	else{
		echo "<h1>Webpage not available</h1>";
	}
	
	if ($show){
		echo "<input type = 'text' id = 'inputword'></input><br>";
		echo "<button id = 'run'>Run</button><br>";
		echo "<div id = 'simulation'></div>";
		
	}
	
?>
<script>
	
	var theTape = new TMTape();
	setUpCanvas();
	
	$(document).ready(function(){
		drawGraph();
	});
	
	
</script>