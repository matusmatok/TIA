<?php
	session_start();
	include 'dbh.php';

?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="global.css">
	<link rel="stylesheet" href="header.css">
	<style>
		#login_container {
			padding: 0%;
			padding-bottom: 0%;
			padding-top: 15px;
			background-color: #F2F9FF;
			color: #2DA6FF;
			text-alig: center;
		}
		#separator{
			height: 36px;
			background-color: #2DA6FF;
			font-size: 32px;
			color: white;
			text-align: center;
		}
		#test{
			text-align: center;
			padding: 0%;
			padding-top: 24%;
			padding-bottom: 20px;
			background-color: #F2F9FF;
		}
		button{
			font-size: 35px;
		}
		a{
			font-size: 35px;
		}
		body{
			background-color: #F2F9FF;
		}
	</style>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
	<script>
		$(document).ready(function() { 
			$("#btn").click(function() {
				$("#login_container").load("login.php");
			});
		});
			
		/*$(document).ready(function() {	
			$("#login").click(function() {
				$("#login_container").load("login.php",{
					username: $("#")
					password: $("#password").val()
				});
			});
		});*/
		
	</script>

</head>
<body>

<div id = "test">
	<a href= "editRun.php"> Create new Turing machine</a>
</div>

<div id = "separator">
<p>-- OR -- </p>
<div>

<div id = "login_container">
<?php
 if (!isset($_SESSION['uid'])){
?>
<button id= "btn">Log in</button>
<?php
 }
 else{
	echo "<p>Welcome back ".$_SESSION['uname']."!</p>";
	echo "<a href = 'profile.php?uid=".$_SESSION['uid']."'>Go to your profile</a>";
 }
?>
</div>

</body>
</html>