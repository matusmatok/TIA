<?php
	if (session_status() !== PHP_SESSION_ACTIVE){
		session_start();
	}
?>
<script>
	function findGetParameter(parameterName) {
		var result = null,
			tmp = [];
		var items = location.search.substr(1).split("&");
		for (var index = 0; index < items.length; index++) {
			tmp = items[index].split("=");
			if (tmp[0] === parameterName) result = decodeURIComponent(tmp[1]);
		}
		return result;
	}

	$(document).ready(function(){
		
		$("#gotoRun").click(function(){
			
			let tmid = $("#tmid").html();
			let owner_id = $("#owner_id").html();
			let p_public = $("#p_public").html();
			
			let description = $("#description").val();
			let title = $("#title").val();
			let delta_function = $("#delta_function").val();
			let input_chars = $("#input_chars").val();
			let work_chars = $("#work_chars").val();
			
			let initial_state = $("#initial_state").val();
			let accepting_states = $("#accepting_states").val();
			let states = $("#states").val();
			
			let url = "runSubpage.php?tmid=" + findGetParameter("tmid");
			
			page = 0;
			
			$.post(url, {
				tmid: tmid,
				description: description,
				title: title,
				owner_id: owner_id,
				p_public: p_public,
				delta_function: delta_function,
				input_chars: input_chars,
				work_chars: work_chars,
				initial_state: initial_state,
				accepting_states: accepting_states,
				states: states
				
			}, function(data, status){
				$("#content").html(data);
			});
		});
	});
	
	$(document).ready(function(){
		$("#save").click(function(){
			let tmid = $("#tmid").html();
			let owner_id = $("#owner_id").html();
			let p_public = $("#p_public").html();
			
			let description = $("#description").val();
			let title = $("#title").val();
			let delta_function = $("#delta_function").val();
			let input_chars = $("#input_chars").val();
			let work_chars = $("#work_chars").val();
			
			let initial_state = $("#initial_state").val();
			let accepting_states = $("#accepting_states").val();
			let states = $("#states").val();
			
			let url = "save.php";
			let jsonCode = theGraph.createJSON();
			
			
			$.post(url,{
				tmid: tmid,
				description: description,
				title: title,
				owner_id: owner_id,
				p_public: p_public,
				delta_function: delta_function,
				input_chars: input_chars,
				work_chars: work_chars,
				initial_state: initial_state,
				accepting_states: accepting_states,
				states: states,
				code: jsonCode
			}, function(data, status){
				$("#hidden").html(data);
				alert("Turing machine saved");
			});
			
		});
	});
	
	$(document).ready(function(){
		$("#states").keyup(function(){
			rebootGraph();
		});
	});
	
	$(document).ready(function(){
		$("#delta_function").keyup(function(){
			rebootGraph();
		});
	});
		

</script>
<?php	
	
	echo "<h1 id = 'page'>Edit the turing machine</h1>";
	
	$render = true;
	
	if (isset($_POST['tmid'])){
		if (!isset($_SESSION['uid'])) $render = false;
		if (isset($_SESSION['uid']) && $_SESSION['uid'] !== $_POST['owner_id']) $render = false;
		if ($_POST['tmid'] == -1) $render = true;
	}
	
	if ($render){
		
		echo "<div id ='canvasDiv'><canvas></canvas></div>";
		echo "<div id = 'hidden' hidden><p id = 'owner_id' hidden>".$_POST['owner_id']."</p>";
		echo "<p id = 'p_public' hidden>".$_POST['p_public']."</p>";
		echo "<p id = 'tmid' hidden>".$_POST['tmid']."</p></div>";
		echo "<h4>Name:</h4>";
		echo "<input type = 'text' id = 'title' value = '". (isset($_POST['title']) ? $_POST['title'] : "Untitled turing machine")."'><br>";
		echo "<h4>Description:</h4>";
		echo "<input type = 'text' id = 'description' value = '". (isset($_POST['title']) ? $_POST['description'] : "No description..")."'><br>";
		echo "<h4>Input characters:</h4>";
		echo "<input type = 'text' id = 'input_chars' value ='".$_POST['input_chars']."'><br>";
		echo "<h4>Working characters: </h4>";
		echo "<input type = 'text' id = 'work_chars' value = '".$_POST['work_chars']."'><br>";
		echo "<h4>States:</h4>";
		echo "<input type = 'text' id = 'states' value ='".$_POST['states']."'></input>";
		echo "<h4>Initial state:</h4>";
		echo "<input type = 'text' id = 'initial_state' value='".$_POST['initial_state']."'></input>";
		echo "<h4>Accepting states:</h4>";
		echo "<input type = 'text' id = 'accepting_states' value='".$_POST['accepting_states']."'></input>";
		echo "<h4>Delta function</h4>";
		echo "<p class ='edit'>Please use the following format:</p>";
		echo "<p class ='edit'>(state, {character1, .., characterN}) = (next state, new character, movement) ;</p>";
		echo "<textarea id = 'delta_function'>".$_POST['delta_function']."</textarea><br><br>";
		echo "<button id = 'gotoRun'>Try running it</button>";
		if (isset($_SESSION['uid']) && ($_SESSION['uid'] == $_POST['owner_id'] or $_POST['tmid'] == "-1")) {
			echo "<button id = 'save'>Save</button>";
		}
	}
	else{
		echo "<h1>Access denied</h1>";
	}
?>
<script>
	setUpCanvas();
	$(document).ready(function(){
		drawGraph();
	});
	
	var drag = false;
	var offsetX = 0;
	var offsetY = 0;
	var formerX = 0;
	var formerY = 0;
	var currentX = 0;
	var currentY = 0;
	var draggedElement = undefined;
	
	var canvas = document.querySelector('canvas');
	canvas.addEventListener('mousedown', function(event){
		getCursorPosition(canvas, event);
		
		let states = theGraph.getStates();
		let stateKeys = Object.keys(states);
		stateKeys.forEach(function(element){
			let state = states[element];
			if (Math.sqrt(Math.pow(currentX - state.x,2) + Math.pow(currentY - state.y,2)) <= 30){
				drag = true;
				draggedElement = state;
				formerX = currentX;
				formerY = currentY;
				offsetX = draggedElement.x - formerX;
				offsetY = draggedElement.y - formerY;
			}
		});
		
	});
	
	canvas.addEventListener('mousemove', function(event){
		if (drag){
			getCursorPosition(canvas, event);
			draggedElement.x = currentX - offsetX;
			draggedElement.y = currentY - offsetY;
			drawGraph();
		}
	});
	
	canvas.addEventListener('mouseup', function(event){
		draggedElement = undefined;
		drag = false;
	});

	
	function getCursorPosition(canvas, event) {
		const rect = canvas.getBoundingClientRect();
		currentX = event.clientX - rect.left;
		currentY = event.clientY - rect.top;
	}
	
</script>

