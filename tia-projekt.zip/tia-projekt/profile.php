<?php
	session_start();
	include 'dbh.php';
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="global.css">
	<link rel="stylesheet" href="header.css">
	<style>
		.tm_overview{
			border: 4px solid #1A97FF;
			margin-top: 25px;
			padding-bottom: 7px;
			padding-right: 20px;
			border-radius: 7px;
			background-color: #cce8ff;
		}
		.tm_overview a{
			float: right;
		}
		.actions{
			margin-top: 10px;
			float: right;
		}
	</style>
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
	<script>
		
		function findGetParameter(parameterName) {
			var result = null,
				tmp = [];
			var items = location.search.substr(1).split("&");
			for (var index = 0; index < items.length; index++) {
				tmp = items[index].split("=");
				if (tmp[0] === parameterName) result = decodeURIComponent(tmp[1]);
			}
			return result;
		}
		
		function reloadContent() {
			$(document).ready(function(){
				var id = findGetParameter("uid");
				$.post("profileSubpage.php",{
					uid: id
				}, function(data,status){
					$("#content").html(data);
				});
			});
		}
		
		$(document).ready(function(){
			$("#testbutton").click(function(){
				reloadContent();
				
			});
		});
	</script>

</head>
<body>
<header>
<?php 
	include 'header.php';
?>
</header>
<div id = "content">
</div>
</body>

<script>
	reloadContent();
</script>
</html>