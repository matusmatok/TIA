<script>
	function nextStep(){
		let charAt = theTape.getCurrentChar();
		let nextState = theGraph.getCurrentState().getNextState()[charAt];
		if (nextState != null){
			let writeChar = theGraph.getCurrentState().getWriteChar()[charAt];
			let move = theGraph.getCurrentState().getHeadMovement()[charAt];
			theTape.step(writeChar,move);
			$("#simTape").html(theTape.produceString());
			theGraph.goToNextState(charAt);
			$("#currentState").html(nextState.name);
			return true;
		}
		else{
			if (theGraph.getCurrentState().accept){
				$("#currentState").html(theGraph.getCurrentState().name);
				$("#currentState").css({
					"background-color" : "#56FF22"
				});
			}
			else{
				$("#currentState").html(theGraph.getCurrentState().name);
				$("#currentState").css({
					"background-color" : "#FF7676"
				});
			}
			$("#nextStep").attr("disabled", true);
			$("#autoSteps").attr("disabled", true);
			return false;
		}
	}
		
	$(document).ready(function(){
		$("#nextStep").click(function(){
			nextStep();
			drawGraph();
		});
	});
		
	$(document).ready(function(){
		$("#autoSteps").click(function() {
			let amount = $("#howMany").val();
			if (amount === "") amount = 0;
			for (i = 0; i< amount; i++){
				if (nextStep() == false) break;
			}
			drawGraph();
		});
	});

</script>
<?php
	echo "<p id = 'simTape'>" . $_POST['tape'] . "</p><p id = 'currentState'>" . $_POST['state'] . "</p>" . "<button id = 'nextStep'>Next step</button><span id = 'runText'>Run automatically for </span><input type = 'text' id = 'howMany' value = '0'><span id = 'runTextCont'> steps -></span><button id = 'autoSteps'>Run automaticaly</button>";
?>
<script>
	$("#simTape").css({
		"max-width": "42%",
		"word-wrap": "break-word",
		"font-size": "22px"
	});
	$("#simulation").css({
		"margin-top" : "20px"
	});
	$("#currentState").css({
		"border-radius" : "5px",
		"padding" : "4px",
		"background-color" : "#7EC8FF",
		"width" : "50px",
		"text-align" : "center",
		"font-size" : "36px"
	});
</script>