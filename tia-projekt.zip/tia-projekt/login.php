<?php
	session_start();
	include 'dbh.php';
	
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jsSHA/2.0.2/sha.js"></script>
<script>
	function sha512(str) {
		return crypto.subtle.digest("SHA-512", new TextEncoder("utf-8").encode(str)).then(buf => {
			return Array.prototype.map.call(new Uint8Array(buf), x=>(('00'+x.toString(16)).slice(-2))).join('');
		});
	}

	$(document).ready(function() {	
		$("#login").click(function() {
			
			var password = sha512($("#password").val()).then(function(x){
				$("#login_container").load("login.php",{
					username: $("#username").val(),
					password: x
				});
				console.log(x);
			});
		});
	});
</script>

<?php
	if (!isset($_POST['username'])){
?>
	<form action="/login.php" method="post">
		<label for = "username">Username:</label>
		<input type = "text" id = "username" name = "username"><br><br>
		<label for = "password">Password:</label>
		<input type = "password" id = "password" name = "password">
	</form>
	<button id = "login" >Log in</button>
<?php
	}
	else{
		$sql = "SELECT * FROM user WHERE name = '".$_POST['username']."' AND password = '".$_POST['password']."'";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
			$row = $result->fetch_assoc();
			echo "<p>Welcome back ".$row['name']."!</p>"; 
			$_SESSION['uid'] = $row['id'];
			$_SESSION['uname'] = $row['name'];
			echo "<a href = 'profile.php?uid=".$row['id']."'>Go to your profile</a>";

		} 
		else {
		    ?>
	<form action="/login.php" method="post">
		<label for = "username">Username:</label>
		<input type = "text" id = "username" name = "username"><br><br>
		<label for = "password">Password:</label>
		<input type = "password" id = "password" name = "password"><br>
	</form>
	<p>Wrong user name or password.</p><br>
	<button id = "login" >Log in</button>
			
<?php			
		}
		
	}
?>


		
		
		