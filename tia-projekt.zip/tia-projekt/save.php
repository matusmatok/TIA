<?php
	session_start();
	include "dbh.php";

	if ($_POST['tmid'] == "-1"){
		$sql = "INSERT INTO turing_machines (owner_id, delta_function, input_chars, work_chars, initial_state, accepting_states, states, code, public, title, description) VALUES ('".$_SESSION['uid']."', '".$_POST['delta_function']."', '".$_POST['input_chars']."', '".$_POST['work_chars']."', '".$_POST['initial_state']."', '".$_POST['accepting_states']."', ".$_POST['states'].", '', '".$_POST['p_public']."', '".$_POST['title']."', '".$_POST['description']."');";
		
		$result = $conn->query($sql);
		
		$last_id = $conn -> insert_id;
		
		echo "<p id = 'owner_id' hidden>".$_SESSION['uid']."</p>";
		echo "<p id = 'p_public' hidden>".$_POST['p_public']."</p>";
		echo "<p id = 'tmid' hidden>".$last_id."</p>";
		
	}
	else{
		$sql = "UPDATE turing_machines SET owner_id = '".$_SESSION['uid']."',
		delta_function = '".$_POST['delta_function']."',
		input_chars = '".$_POST['input_chars']."',
		work_chars = '".$_POST['work_chars']."',
		initial_state = '".$_POST['initial_state']."',
		accepting_states = '".$_POST['accepting_states']."',
		states = '".$_POST['states']."',
		public = '".$_POST['p_public']."',
		title = '".$_POST['title']."',
		code = '".$_POST['code']."',
		description = '".$_POST['description']."' WHERE id = '".$_POST['tmid']."'";
		
		$conn->query($sql);	

		
		
		echo "<p id = 'owner_id' hidden>".$_POST['owner_id']."</p>";
		echo "<p id = 'p_public' hidden>".$_POST['p_public']."</p>";
		echo "<p id = 'tmid' hidden>".$_POST['tmid']."</p>";
	}
?>
