<script>
	$(document).ready(function(){
		$("#publish").click(function(){
			let tmid = $("#tmid").html();
			let text = $("#newCommentBody").val();
			$.post("insertComment.php",{
				tmid: tmid,
				comment: text
			},function(data, status){
				console.log(data);
			});
			refreshComments();
		});
	});
</script>

<?php
	if (session_status() !== PHP_SESSION_ACTIVE){
		session_start();
	}
	include "dbh.php";
	
	if (isset($_SESSION['uid'])){
		echo "<h3>Add new comment</h3>";
		echo "<textarea id = 'newCommentBody'></textarea><br>";
		echo "<button id = 'publish'>Comment</button>";
	}

?>
<script>
	$("#newCommentBody").css({
		"resize" : "none",
		"height" : "100px"						
	});
</script>