<?php
	if (session_status() !== PHP_SESSION_ACTIVE){
		session_start();
	}
	include 'dbh.php';
?>
<div id = "userInfo">
	
	<?php
	$sql = "SELECT * FROM user WHERE name ='".$_POST['newUsername']."'";
	$result = $conn->query($sql);
	
	if ($result->num_rows > 0) {
		$row = $result->fetch_assoc(); 
		echo 
	}
	?>

</div>
<div id = "userActions">

</div>